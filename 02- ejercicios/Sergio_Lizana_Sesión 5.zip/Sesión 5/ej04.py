# -*- coding: utf-8 -*-

fichero = open("lista.txt", "r")

for linea in fichero:
	print linea
	
fichero.close()
