#!/usr/bin/python
#A comment, this is so you can read your program later.
#Anything after the # is ignored by python.

print "I could have code like this." #and the comment after is ignored

#you can also use a comment to "disable" or comment out a piece of code:
#print "this won't run."

print "this will run."
