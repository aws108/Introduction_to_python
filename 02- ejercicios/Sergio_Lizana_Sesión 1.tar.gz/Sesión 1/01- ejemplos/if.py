#!/usr/bin/python
#versio1

edat_usuari=int(raw_input("edat?"))
print"tens "
if edat_usuari==1:
	print "un any"
else:
	if edat_usuari==2:
		print "dos anys"
	else:
		if edat_usuari==3:
			print "tres anys"
		else:
			if edat_usuari==4:
				print "quatre anys"
			else:
					print "mes de 4 anys"
