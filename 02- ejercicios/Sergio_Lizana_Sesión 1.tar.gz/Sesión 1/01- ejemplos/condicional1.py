#!/usr/bin/python

a=2
b=3
if a==b:
	print("son iguals")
else:
	print("son diferents")
