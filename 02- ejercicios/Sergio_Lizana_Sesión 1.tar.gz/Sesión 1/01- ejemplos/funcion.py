#!/usr/bin/python

def imprimeix_taula(numero): 
	for i in range(10):
		print "%d*%d=%d" % (numero, 1, numero*i)
		
		
imprimeix_taula(3)
print "\n"
imprimeix_taula(9)
print "\n"
