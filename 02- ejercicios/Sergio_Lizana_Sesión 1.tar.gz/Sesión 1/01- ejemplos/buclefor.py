#!/usr/bin/python

for i in ["/", "-", "|", "\\", "|"]:
	print "%s \r" % i
	raw_input()
