#!/usr/bin/python
# -*- coding: utf-8 -*-
print "mira què bé"
