#!/usr/bin/python

import sys
params = sys.argv
nom = params[1]
print "Hola, %s" % (nom)
