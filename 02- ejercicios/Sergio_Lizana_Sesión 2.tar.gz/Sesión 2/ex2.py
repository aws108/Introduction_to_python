def cheese_and_crackers (cheese_count, boxes_of_crackers):
	print "You have %d cheeses!" % cheese_count
	print "You have %d boxes of crackers!" % boxes_of_crackers
	print "Man that's enough for a party!"
	print "Get a blanker. \n"

print("Introduce el num de cheese y el num de crakers")
amount_of_cheese=int(raw_input())
amount_of_crackers=int(raw_input())
cheese_and_crackers(amount_of_cheese, amount_of_crackers)

amount_of_cheese=int(raw_input("Introduce amount of cheese"))
amount_of_crackers=int(raw_input("Introduce amount of crackers"))
cheese_and_crackers(amount_of_cheese, amount_of_crackers)


